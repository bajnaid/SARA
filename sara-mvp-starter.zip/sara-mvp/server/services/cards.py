from datetime import datetime
from .calendar_google import get_today_events
from .finance_plaid import get_money_snapshot
from .ai_coach import plan_today_summary, nightly_review_summary

async def compose_current_card() -> dict:
    hour = datetime.now().hour
    if hour <= 12:
        events = await get_today_events()
        body = await plan_today_summary(events)
        return {"type": "plan", "title": "Plan Today", "body": body, "cta": "Start Focus"}
    elif hour < 20:
        money = await get_money_snapshot()
        body = (
            f"Spend today: ${money['spend_today']:.2f} | "
            f"Left today: ${money['budget_left_today']:.2f} | "
            f"Week: ${money['spend_week']:.2f}"
        )
        return {"type": "money", "title": "Money Snapshot", "body": body, "cta": "Open Budget"}
    else:
        body = "60-sec check-in: What went well? What blocked you? What to try tomorrow?"
        return {"type": "reflect", "title": "Nightly Review", "body": body, "cta": "Log Reflection"}

async def save_reflection(text: str) -> dict:
    summary = await nightly_review_summary(text, "Week-to-date: $96.30")
    return {"ok": True, "summary": summary}
