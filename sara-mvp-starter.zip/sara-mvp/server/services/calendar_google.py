from datetime import datetime, timedelta, timezone

async def get_today_events() -> list:
    now = datetime.now(timezone.utc)
    return [
        {"title": "Studio Work Block", "start_iso": (now+timedelta(hours=1)).isoformat(), "end_iso": (now+timedelta(hours=2)).isoformat()},
        {"title": "Class: Design Theory", "start_iso": (now+timedelta(hours=3)).isoformat(), "end_iso": (now+timedelta(hours=4)).isoformat()},
    ]
